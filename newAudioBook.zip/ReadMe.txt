The folder contains all the components needed for execution.
final.py: It is the flask app.

static: Location which is statically used while the application runs. 
The QR code will be downloaded in the "images" folder inside this folder.
It contains the web designing css files.

templates: Various html templates used for designing the UI.

client_secrets: Used for authenticating the Google Account.

Youtube Video Link: 
https://www.youtube.com/watch?v=pLZ4Yv60kR8 

GitHub Link: 
https://github.com/tatsat99/Digital-Audio-article-using-Flask 
 
Various documents required are also submited, inclduing 2 word documents and 1 power point presentation.




